package com.techment.day10.jdbc;

public interface ConnectionProperty {
 public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
 public static final String URL = "jdbc:mysql://localhost:5000/techment?autoReconnect=true&useSSL=false";
 public static final String USERNAME = "root";
 public static final String PASSWORD = "Bodygaurd@2013";
}
