//package com.techment.day10.jdbc;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//public class ConnectionDetails implements ConnectionProperty {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		try {
//			
//			
//				
//				Class.forName(ConnectionProperty.DRIVER_NAME)
//				Connection con = DriverManager.getConnection(ConnectionProperty.URL,ConnectionProperty.USERNAME,ConnectionProperty.PASSWORD);
//				
//				return con;
//		}catch(Exception e) {
//			System.out.println(e);
//		}
//		
//		}
//	
//
//	}
//
//}
